import { V, _ } from "../chunks/2.D-u4wcY2.js";
export {
  V as component,
  _ as universal
};
